# Nooshad School Node.js

Persian RTL school website and role-based school portal.

- Runtime: Node.js 22
- Start: `npm start`
- Health endpoint: `/health`
- Initial owner: configure `OWNER_USERNAME` and `OWNER_PASSWORD` in the host environment before first database initialization. The public `/setup` page has been removed.
- Optional Kavenegar SMS: configure `KAVENEGAR_API_KEY` and `KAVENEGAR_SENDER`.
- Render instructions: see `README_RENDER_FA.md`.

Important: SQLite and uploaded images require persistent storage for real school use. Do not rely on ephemeral free-tier storage for student records.
