// Nooshad UI interactions: accessible menus and safe form feedback.
(function(){
  const body=document.body;
  function setExpanded(button,value){if(button)button.setAttribute('aria-expanded',String(value));}
  function closeSiteMenu(header){header.classList.remove('menu-open','menu-collapsed');const b=header.querySelector('.hamb');setExpanded(b,false);}
  document.addEventListener('click',function(e){
    const siteButton=e.target.closest('.site-header .hamb');
    if(siteButton){
      e.preventDefault();const header=siteButton.closest('.site-header');
      if(window.matchMedia('(max-width: 900px)').matches){const open=header.classList.toggle('menu-open');setExpanded(siteButton,open);}
      else{const collapsed=header.classList.toggle('menu-collapsed');setExpanded(siteButton,!collapsed);}
      return;
    }
    const appButton=e.target.closest('.app-body .app-top .hamb');
    if(appButton){e.preventDefault();const open=body.classList.toggle('nav-open');setExpanded(appButton,open);return;}
    if(e.target.closest('.sidebar-close')||e.target.classList.contains('app-backdrop')){body.classList.remove('nav-open');setExpanded(document.querySelector('.app-top .hamb'),false);return;}
    const siteLink=e.target.closest('.site-header nav a');
    if(siteLink){closeSiteMenu(siteLink.closest('.site-header'));}
    const appLink=e.target.closest('.sidebar nav a');
    if(appLink&&window.innerWidth<=900){body.classList.remove('nav-open');setExpanded(document.querySelector('.app-top .hamb'),false);}
  });
  document.addEventListener('keydown',function(e){if(e.key==='Escape'){body.classList.remove('nav-open');setExpanded(document.querySelector('.app-top .hamb'),false);document.querySelectorAll('.site-header').forEach(closeSiteMenu);}});
  window.addEventListener('resize',function(){if(window.innerWidth>900){body.classList.remove('nav-open');setExpanded(document.querySelector('.app-top .hamb'),false);const h=document.querySelector('.site-header');if(h){h.classList.remove('menu-open');}}else{document.querySelectorAll('.site-header').forEach(h=>h.classList.remove('menu-collapsed'));}});
  document.querySelectorAll('form').forEach(function(form){form.addEventListener('submit',function(){if(!form.checkValidity())return;const button=form.querySelector('button[type="submit"],button:not([type])');if(button&&!button.dataset.busy){button.dataset.busy='1';button.dataset.oldText=button.textContent;button.textContent='در حال ثبت…';button.setAttribute('aria-busy','true');}});});
})();

// Three-position autumn hero carousel: controls, dots and automatic rotation.
(function(){
 const hero=document.querySelector('.orange-hero'); if(!hero)return;
 const title=hero.querySelector('h1'), desc=hero.querySelector('.alavi-hero-copy p');
 const dots=[...hero.querySelectorAll('.hero-dots button')];
 const slides=[
  {title:'مدرسه حاج محمدباقر نوشاد شیراز',desc:'محیطی برای یادگیری، پرورش استعدادها، تجربه‌های تازه و ساختن آینده‌ای روشن؛ همراه دانش‌آموزان در مسیر رشد علمی و شخصیتی.',pos:'48%'},
  {title:'جایی برای کشف و پرورش استعدادها',desc:'با پرسشگری، خلاقیت و تلاش پیوسته، مسیر یادگیری را به تجربه‌ای ماندگار و الهام‌بخش تبدیل می‌کنیم.',pos:'30%'},
  {title:'امروز یاد می‌گیریم؛ فردا می‌سازیم',desc:'همراهی خانواده و کادر آموزشی، پایه‌ای برای رشد علمی، مسئولیت‌پذیری و ساختن آینده‌ای روشن است.',pos:'68%'}
 ]; let index=0;
 function show(n){index=(n+slides.length)%slides.length;const s=slides[index];title.textContent=s.title;desc.textContent=s.desc;hero.style.backgroundPosition=`center ${s.pos}`;hero.dataset.slide=String(index+1);dots.forEach((d,i)=>{d.classList.toggle('active',i===index);d.setAttribute('aria-selected',String(i===index));});}
 hero.querySelector('.hero-prev')?.addEventListener('click',()=>show(index-1));hero.querySelector('.hero-next')?.addEventListener('click',()=>show(index+1));dots.forEach((d,i)=>d.addEventListener('click',()=>show(i)));
 let timer=setInterval(()=>show(index+1),6500);hero.addEventListener('mouseenter',()=>clearInterval(timer));hero.addEventListener('mouseleave',()=>{clearInterval(timer);timer=setInterval(()=>show(index+1),6500)});
})();
